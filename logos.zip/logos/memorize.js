"use strict";var D=Object.defineProperty;var x=Object.getOwnPropertyDescriptor;var T=Object.getOwnPropertyNames;var P=Object.prototype.hasOwnProperty;var H=(r,e)=>{for(var n in e)D(r,n,{get:e[n],enumerable:!0})},Y=(r,e,n,t)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of T(e))!P.call(r,s)&&s!==n&&D(r,s,{get:()=>e[s],enumerable:!(t=x(e,s))||t.enumerable});return r};var E=r=>Y(D({},"__esModule",{value:!0}),r);var k={};H(k,{default:()=>M});module.exports=E(k);var h=require("@raycast/api"),o=require("fs"),w=require("path");var y=require("@raycast/api");function l(r,e){let n=Intl.DateTimeFormat().resolvedOptions().locale,t=(g,f=2)=>String(g).padStart(f,"0"),s=new Intl.DateTimeFormat(n,{weekday:"long"}).format(e),c=new Intl.DateTimeFormat(n,{weekday:"short"}).format(e),a=new Intl.DateTimeFormat(n,{month:"long"}).format(e),m=new Intl.DateTimeFormat(n,{month:"short"}).format(e),d=[[/YYYY/g,String(e.getFullYear())],[/YY/g,String(e.getFullYear()).slice(-2)],[/MMMM/g,a],[/MMM/g,m],[/MM/g,t(e.getMonth()+1)],[/M(?!M)/g,String(e.getMonth()+1)],[/DD/g,t(e.getDate())],[/D(?!D)/g,String(e.getDate())],[/dddd/g,s],[/ddd/g,c],[/HH/g,t(e.getHours())],[/mm/g,t(e.getMinutes())],[/ss/g,t(e.getSeconds())]],p=r;for(let[g,f]of d)p=p.replace(g,f);return p}function S(r,e,n){let t=r;t=t.replace(/\{\{title\}\}/g,e.replace(/\.md$/,"")),t=t.replace(/\{\{date:([^}]+)\}\}/g,(c,a)=>l(a,n));let s=(0,y.getPreferenceValues)();return t=t.replace(/\{\{date\}\}/g,l(s.filenameTemplate,n)),t=t.replace(/\{\{time:([^}]+)\}\}/g,(c,a)=>l(a,n)),t=t.replace(/\{\{time\}\}/g,l("HH:mm",n)),t}function I(r){return r.split(/[\s,]+/).filter(Boolean).map(e=>e.startsWith("#")?e:`#${e}`).join(" ")}async function M(r){let e=(0,h.getPreferenceValues)(),{text:n,tags:t}=r.arguments,s=new Date,c=l(e.filenameTemplate,s)+".md",a=e.notesDirectory.replace(/^~/,process.env.HOME??"~"),m=(0,w.join)(a,c);(0,o.existsSync)(a)||(0,o.mkdirSync)(a,{recursive:!0});let d=l("HH:mm",s),p=t?.trim()?" "+I(t):"",g=`**${d}** ${n.trim()}${p}`,f=!1;if((0,o.existsSync)(m)){let i=(0,o.readFileSync)(m,"utf-8"),u=i.length===0||i.endsWith(`

`)?"":i.endsWith(`
`)?`
`:`

`;(0,o.appendFileSync)(m,u+g+`
`,"utf-8")}else{f=!0;let i="";if(e.templateFile){let u=e.templateFile.replace(/^~/,process.env.HOME??"~");if((0,o.existsSync)(u)&&(0,o.statSync)(u).isFile()){let F=(0,o.readFileSync)(u,"utf-8");i=S(F,c,s)}}i.length>0&&!i.endsWith(`
`)&&(i+=`
`),i.length>0&&(i+=`
`),i+=`---

`,i+=g+`
`,(0,o.writeFileSync)(m,i,"utf-8")}f?await(0,h.showHUD)("\u{1F535} New daily note created successfully"):await(0,h.showHUD)("\u{1F7E2} Note added to daily note successfully")}
